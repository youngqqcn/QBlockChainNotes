#include "printer.h"

void CPrinter::Show()
{
    std::cout << "a=" << a << "b=" << b << std::endl; 
}