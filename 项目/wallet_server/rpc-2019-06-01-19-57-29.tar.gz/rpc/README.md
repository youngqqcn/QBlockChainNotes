

# 1.安装依赖

```
make deps
```



# 2.启动服务 


根据不同环境, 选择以下命令启动即可
```

#DEV启动   make start-dev
#SIT启动   make start-sit
#UAT启动   make start-uat
#PRO启动   make start-pro


```
 



