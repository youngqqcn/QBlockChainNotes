
cp libs/* /lib64


yum update

yum install  dnf

dnf install gcc-c++ libtool make autoconf automake openssl-devel libevent-devel  libdb-devel libdb-cxx-devel
