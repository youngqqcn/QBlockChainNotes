生成同名的静态库和动态库


gcc 默认导出所有的符号symbolic
vc++ 只导出指定的符号

如:

- libprinter.a
- libprinter.so