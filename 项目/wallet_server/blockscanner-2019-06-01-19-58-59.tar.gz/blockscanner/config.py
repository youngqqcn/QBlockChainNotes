#coding:utf8
import os


#############  ETH  #####################
ETH_N_BLOCK_TO_WAIT_CONFIRM = 12         #区块确认数至少12个
ETH_NODE_RPC_HOST = "192.168.10.199"     #
#ETH_NODE_RPC_HOST = "api.etherscan.io"  #备用方案
ETH_NODE_RPC_PORT = 18545                 #如果是备用方案,使用8545即可
##########################################

############ USDP #########################
#47.98.194.7
#39.106.72.143
#47.75.245.31
#47.88.173.14
#USDP_NODE_RPC_HOST = "47.99.81.158"
#USDP_NODE_RPC_HOST = "47.88.173.14"
USDP_NODE_RPC_HOST = "192.168.10.23"
USDP_NODE_RPC_PORT = 1317
USDP_N_BLOCK_TO_WAIT_CONFIRM = 2     #区块确认数至少12个
##########################################

############ HTDF #########################
#47.99.81.158
#39.106.90.41
#47.75.88.24
#47.88.169.30
#HTDF_NODE_RPC_HOST = "47.88.173.14"
#HTDF_NODE_RPC_HOST = "47.88.169.30"
HTDF_NODE_RPC_HOST = "192.168.10.69"
#HTDF_NODE_RPC_HOST = "192.168.10.70"
HTDF_NODE_RPC_PORT = 1317
HTDF_N_BLOCK_TO_WAIT_CONFIRM = 2     #区块确认数至少12个
##########################################

############# MYSQL #####################
SQL_IP_ADDR, SQL_PORT = '127.0.0.1',3306
SQL_USRNAME = 'root'
SQL_PASSWD = os.environ.get('SQL_PWD')
DBNAME =  'wallet'
#############################################
